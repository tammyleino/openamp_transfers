var searchData=
[
  ['to_5flinux_5fbus_0',['to_linux_bus',['../system_2linux_2device_8c.html#a04205c882d2a3403550653812492f02b',1,'device.c']]],
  ['to_5flinux_5fdevice_1',['to_linux_device',['../system_2linux_2device_8c.html#a14ea187d2b10cbed6c5740c4bf115fc8',1,'device.c']]]
];
