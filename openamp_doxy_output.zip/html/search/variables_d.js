var searchData=
[
  ['p_5falign_0',['p_align',['../structElf32__Phdr.html#afd09d9e4297b13fc94fd57d09f2a9f70',1,'Elf32_Phdr::p_align()'],['../structElf64__Phdr.html#aa89a4b1835998c8866e821d777a2f879',1,'Elf64_Phdr::p_align()']]],
  ['p_5ffilesz_1',['p_filesz',['../structElf32__Phdr.html#ac9151f2e11001284bf1c7d2d2659555c',1,'Elf32_Phdr::p_filesz()'],['../structElf64__Phdr.html#af50e5756da2acda5ccb02ebaa3367092',1,'Elf64_Phdr::p_filesz()']]],
  ['p_5fflags_2',['p_flags',['../structElf32__Phdr.html#a35c457e6828894b7b275730593802050',1,'Elf32_Phdr::p_flags()'],['../structElf64__Phdr.html#ab96e7784733c2192a76d5a42897cb38b',1,'Elf64_Phdr::p_flags()']]],
  ['p_5fmemsz_3',['p_memsz',['../structElf32__Phdr.html#ada1cdd3d6ccb79a17bed0e3c21379c84',1,'Elf32_Phdr::p_memsz()'],['../structElf64__Phdr.html#a55fae01175fc4e3f1c23e52b14459235',1,'Elf64_Phdr::p_memsz()']]],
  ['p_5foffset_4',['p_offset',['../structElf32__Phdr.html#ac590d4c4b26104216e53058b5b03eef0',1,'Elf32_Phdr::p_offset()'],['../structElf64__Phdr.html#aa2d51fb4517ded0c74903f8d0c9abea7',1,'Elf64_Phdr::p_offset()']]],
  ['p_5fpaddr_5',['p_paddr',['../structElf32__Phdr.html#af18f0a179a5fca09e3c04bcdce3fac2f',1,'Elf32_Phdr::p_paddr()'],['../structElf64__Phdr.html#a83f4adb032fc307f5af79bdee5ef692d',1,'Elf64_Phdr::p_paddr()']]],
  ['p_5ftype_6',['p_type',['../structElf32__Phdr.html#a8b1d2942ddb9abcb85db1429b5116923',1,'Elf32_Phdr::p_type()'],['../structElf64__Phdr.html#aee6ec430eaaf8b8faf82ae6397282cb3',1,'Elf64_Phdr::p_type()']]],
  ['p_5fvaddr_7',['p_vaddr',['../structElf32__Phdr.html#a01a298ebc899bcf9c23211a7bf1155a6',1,'Elf32_Phdr::p_vaddr()'],['../structElf64__Phdr.html#a5c69879e1229b175020ff011af46fcb9',1,'Elf64_Phdr::p_vaddr()']]],
  ['pa_8',['pa',['../structfw__rsc__carveout.html#a69849c9f5198675d7e9781b9933b87b0',1,'fw_rsc_carveout::pa()'],['../structfw__rsc__devmem.html#a082e18c4d2701b30de6bc63c6efcb945',1,'fw_rsc_devmem::pa()'],['../structremoteproc__mem.html#a753d5abca792ee92654b5e5286c1d4a1',1,'remoteproc_mem::pa()']]],
  ['pad_9',['pad',['../structvring__alloc__info.html#a31a174d5a45ca70cb31579e79e40c0f4',1,'vring_alloc_info']]],
  ['params_10',['params',['../structrpmsg__rpc__request.html#a91b223ed1cab33ca05cfab38c04fbfe6',1,'rpmsg_rpc_request::params()'],['../structrpmsg__rpc__answer.html#ac5b27611b12e74b3bcd7e726b3f32834',1,'rpmsg_rpc_answer::params()']]],
  ['phdrs_11',['phdrs',['../structelf32__info.html#a2df0a0cd82affb7e17915c62110e886c',1,'elf32_info::phdrs()'],['../structelf64__info.html#a8b50c492229cc422109ffa1ccef9e6e1',1,'elf64_info::phdrs()']]],
  ['poll_12',['poll',['../structrpmsg__rpc__data.html#ae00d967d22a2af20ccdc58e2d1c60b2c',1,'rpmsg_rpc_data']]],
  ['poll_5farg_13',['poll_arg',['../structrpmsg__rpc__data.html#ad44e7b0bb636bf5470e8fab86b1ac276',1,'rpmsg_rpc_data']]],
  ['priv_14',['priv',['../structremoteproc.html#a02f8c03c555901925c3ed59fa6ab2082',1,'remoteproc::priv()'],['../structremoteproc__virtio.html#afb6d34681cd633364f998f544963b0bc',1,'remoteproc_virtio::priv()'],['../structrpmsg__endpoint.html#a0f7728b3f5cad2238765c067e7d6cccc',1,'rpmsg_endpoint::priv()'],['../structvirtio__device.html#a3b0873506c074a6c1ab77cc3404a17b6',1,'virtio_device::priv()']]]
];
