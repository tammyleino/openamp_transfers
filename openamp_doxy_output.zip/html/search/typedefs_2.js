var searchData=
[
  ['rpmsg_5fept_5fcb_0',['rpmsg_ept_cb',['../rpmsg_8h.html#af9d11ac8401619c4ee31fda023144e3a',1,'rpmsg.h']]],
  ['rpmsg_5fns_5fbind_5fcb_1',['rpmsg_ns_bind_cb',['../rpmsg_8h.html#a6935402b87e2f4c21e0ec8003c51e94b',1,'rpmsg.h']]],
  ['rpmsg_5fns_5funbind_5fcb_2',['rpmsg_ns_unbind_cb',['../rpmsg_8h.html#a1d23bf60afd369ed21c86e2c6765e9c9',1,'rpmsg.h']]],
  ['rpmsg_5frpc_5fpoll_3',['rpmsg_rpc_poll',['../rpmsg__retarget_8h.html#a79368b11cf9ce281446187fce00404e3',1,'rpmsg_retarget.h']]],
  ['rpmsg_5frpc_5fshutdown_5fcb_4',['rpmsg_rpc_shutdown_cb',['../rpmsg__retarget_8h.html#a379fd43ed80c85af5d4822395d9c7726',1,'rpmsg_rpc_shutdown_cb():&#160;rpmsg_retarget.h'],['../rpmsg__rpc__client__server_8h.html#a98cd618cdd28c83c6f6d25fd54b151fe',1,'rpmsg_rpc_shutdown_cb():&#160;rpmsg_rpc_client_server.h']]],
  ['rpmsg_5frpc_5fsyscall_5fcb_5',['rpmsg_rpc_syscall_cb',['../rpmsg__rpc__client__server_8h.html#ab7f97be25cf78d3179e17200784c5e15',1,'rpmsg_rpc_client_server.h']]],
  ['rpvdev_5fnotify_5ffunc_6',['rpvdev_notify_func',['../remoteproc__virtio_8h.html#aa140436cc6c9c109432500f2bce35e88',1,'remoteproc_virtio.h']]],
  ['rsc_5fhandler_7',['rsc_handler',['../rsc__table__parser_8h.html#a957779f713f78bffd9a057ddad4fe16a',1,'rsc_table_parser.h']]]
];
