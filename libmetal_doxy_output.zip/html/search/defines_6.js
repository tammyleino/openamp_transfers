var searchData=
[
  ['libmetal_5ferr_5fbase_0',['LIBMETAL_ERR_BASE',['../compiler_2armcc_2errno_8h.html#a136a34750a252db66dba9dca1aa975c5',1,'LIBMETAL_ERR_BASE():&#160;errno.h'],['../compiler_2iar_2errno_8h.html#a136a34750a252db66dba9dca1aa975c5',1,'LIBMETAL_ERR_BASE():&#160;errno.h']]]
];
