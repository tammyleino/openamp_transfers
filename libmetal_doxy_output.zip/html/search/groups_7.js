var searchData=
[
  ['shared_20memory_20interfaces_0',['Shared Memory Interfaces',['../group__shmem.html',1,'']]],
  ['simple_20utilities_1',['Simple Utilities',['../group__utilities.html',1,'']]],
  ['sleep_20interfaces_2',['Sleep Interfaces',['../group__sleep.html',1,'']]],
  ['spinlock_20interfaces_3',['Spinlock Interfaces',['../group__spinlock.html',1,'']]]
];
