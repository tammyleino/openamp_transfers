var searchData=
[
  ['read_0',['read',['../structmetal__io__ops.html#a3cba7140674cb2eeb9fc74ad614ea9fb',1,'metal_io_ops']]],
  ['regions_1',['regions',['../structmetal__device.html#ad6a86618d3c23da03de5d2b0961a8ba1',1,'metal_device']]],
  ['restrict_2',['restrict',['../compiler_2gcc_2compiler_8h.html#a080abdcb9c02438f1cd2bb707af25af8',1,'restrict():&#160;compiler.h'],['../compiler_2iar_2compiler_8h.html#a080abdcb9c02438f1cd2bb707af25af8',1,'restrict():&#160;compiler.h']]]
];
