var searchData=
[
  ['virtio_5fdev_5freset_5fcb_0',['virtio_dev_reset_cb',['../virtio_8h.html#a0dbd8d7b94d502108bf4e2de97e8b33d',1,'virtio.h']]],
  ['vq_5fcallback_1',['vq_callback',['../virtqueue_8h.html#a7bde3cad19649f73237e4dc50357bbc0',1,'virtqueue.h']]],
  ['vq_5fnotify_2',['vq_notify',['../virtqueue_8h.html#a2b4b198a0af55adbf297ff5dcbcfb133',1,'virtqueue.h']]]
];
