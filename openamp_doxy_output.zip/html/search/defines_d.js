var searchData=
[
  ['write_5fsyscall_5fid_0',['WRITE_SYSCALL_ID',['../rpmsg__retarget_8h.html#a0989e433453b5f277c0e75bbf1fe14f2',1,'rpmsg_retarget.h']]]
];
