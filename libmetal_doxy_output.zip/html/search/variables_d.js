var searchData=
[
  ['read_0',['read',['../structmetal__io__ops.html#a3cba7140674cb2eeb9fc74ad614ea9fb',1,'metal_io_ops']]],
  ['regions_1',['regions',['../structmetal__device.html#ad6a86618d3c23da03de5d2b0961a8ba1',1,'metal_device']]]
];
