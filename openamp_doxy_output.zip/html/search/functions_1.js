var searchData=
[
  ['deprecated_5frpmsg_5fmaster_0',['deprecated_rpmsg_master',['../rpmsg__virtio_8h.html#a508be8c672319b00ed6faa111aafc199',1,'rpmsg_virtio.h']]],
  ['deprecated_5frpmsg_5fslave_1',['deprecated_rpmsg_slave',['../rpmsg__virtio_8h.html#acf6798dc78563e0d00a970940c4a6bdd',1,'rpmsg_virtio.h']]],
  ['deprecated_5fvirtio_5fdev_5fmaster_2',['deprecated_virtio_dev_master',['../virtio_8h.html#a90b4781a611bc855a9948546ea22baca',1,'virtio.h']]],
  ['deprecated_5fvirtio_5fdev_5fslave_3',['deprecated_virtio_dev_slave',['../virtio_8h.html#acde50c354e2a0b69eb2a9ef3b2d85049',1,'virtio.h']]]
];
