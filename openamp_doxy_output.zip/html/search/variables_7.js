var searchData=
[
  ['h2r_5fbuf_5fsize_0',['h2r_buf_size',['../structrpmsg__virtio__config.html#aacaedc1cd7284784c8bc213752484e91',1,'rpmsg_virtio_config']]],
  ['handle_5frsc_1',['handle_rsc',['../structremoteproc__ops.html#a412e2d2daa971cafcd0ba1bb9f849355',1,'remoteproc_ops']]],
  ['hold_5frx_5fbuffer_2',['hold_rx_buffer',['../structrpmsg__device__ops.html#acaaf6866829d22778e49064cbd8f3fc4',1,'rpmsg_device_ops']]]
];
