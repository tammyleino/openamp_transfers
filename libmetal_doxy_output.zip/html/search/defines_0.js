var searchData=
[
  ['_5f_5fdeprecated_0',['__deprecated',['../compiler_2gcc_2compiler_8h.html#a4e1585cb1b8a465a6a9a702d97bb4ad8',1,'__deprecated():&#160;compiler.h'],['../compiler_2iar_2compiler_8h.html#a4e1585cb1b8a465a6a9a702d97bb4ad8',1,'__deprecated():&#160;compiler.h']]],
  ['_5f_5fmetal_5flinux_5firq_5f_5fh_5f_5f_1',['__METAL_LINUX_IRQ__H__',['../system_2linux_2irq_8h.html#a175114f8766570fbb6860a7f86f5a390',1,'irq.h']]],
  ['_5f_5fsync_5fsynchronize_2',['__sync_synchronize',['../processor_2ceva_2cpu_8h.html#a3de7c4e7434d2028f0b1bdbe835ce3cb',1,'__sync_synchronize():&#160;cpu.h'],['../processor_2xtensa_2cpu_8h.html#a3de7c4e7434d2028f0b1bdbe835ce3cb',1,'__sync_synchronize():&#160;cpu.h']]]
];
