var searchData=
[
  ['page_5fmask_0',['page_mask',['../structmetal__io__region.html#ae10d7c45fa9e87d93dbb01e87cd7f822',1,'metal_io_region']]],
  ['page_5fshift_1',['page_shift',['../structmetal__io__region.html#a78412204cb2dd9ebed613b3273b9ab1b',1,'metal_io_region::page_shift()'],['../structmetal__page__size.html#a990ff70e16c6efaaf58e47b0948d23a7',1,'metal_page_size::page_shift()'],['../structmetal__state.html#ac47375715b2e69ecb17b3a3714ae5c42',1,'metal_state::page_shift()']]],
  ['page_5fsize_2',['page_size',['../structmetal__page__size.html#a97c5f203beaedb46b0d52425e5445a08',1,'metal_page_size::page_size()'],['../structmetal__state.html#a3ce0623d9131ad2f99e47e78ec3feba3',1,'metal_state::page_size()']]],
  ['page_5fsizes_3',['page_sizes',['../structmetal__state.html#a4488b4117a68b92e40c0c04f53f7310b',1,'metal_state']]],
  ['pagemap_5ffd_4',['pagemap_fd',['../structmetal__state.html#a197661bddfd13e2af962db5802989261',1,'metal_state']]],
  ['path_5',['path',['../structmetal__page__size.html#aea1125ee871f2ddaca6580fc78985113',1,'metal_page_size']]],
  ['phys_5fto_5foffset_6',['phys_to_offset',['../structmetal__io__ops.html#a4f7597eddef002c9a66eb042179c016c',1,'metal_io_ops']]],
  ['physmap_7',['physmap',['../structmetal__io__region.html#a129e040d18e8e6570ed5ce2b7c258e86',1,'metal_io_region']]],
  ['prev_8',['prev',['../structmetal__list.html#ada1c8bdeec046c44a68e5adb22813409',1,'metal_list']]]
];
