var searchData=
[
  ['n_5fservices_0',['n_services',['../structrpmsg__rpc__svr.html#a3c56d6dedc375464fc8993737954c143',1,'rpmsg_rpc_svr::n_services()'],['../structrpmsg__rpc__clt.html#a1b2845bfbfa21e9b0e979f651155fd8c',1,'rpmsg_rpc_clt::n_services()']]],
  ['nacked_1',['nacked',['../structrpmsg__rpc__data.html#aa5f55cfdce812e3a5a3292714f880631',1,'rpmsg_rpc_data']]],
  ['name_2',['name',['../structfw__rsc__carveout.html#a5f9ffd2af51d75bd4a4df87efea90adb',1,'fw_rsc_carveout::name()'],['../structfw__rsc__devmem.html#aa4f0cb316b1d52411e376afa0643b7ba',1,'fw_rsc_devmem::name()'],['../structfw__rsc__trace.html#a14ceab624413a9eb4a13dabd05d7e2c5',1,'fw_rsc_trace::name()'],['../structremoteproc__mem.html#a087ada92ad7d8b8a9479710136d6288d',1,'remoteproc_mem::name()'],['../structrpmsg__endpoint.html#a0fce57c7deb1de894a758df935890903',1,'rpmsg_endpoint::name()'],['../structrpmsg__ns__msg.html#a05a26705a00b47f5037fa09a3d016ade',1,'rpmsg_ns_msg::name()']]],
  ['ndescs_3',['ndescs',['../structvq__desc__extra.html#ada13d12f8981ab0c891200135bb006e6',1,'vq_desc_extra']]],
  ['negotiate_5ffeatures_4',['negotiate_features',['../structvirtio__dispatch.html#a8a41f854178617a2e426944e6fe7c136',1,'virtio_dispatch']]],
  ['next_5',['next',['../structvring__desc.html#a7d1a05acc86ccc917fe06b2f81d0e0d8',1,'vring_desc']]],
  ['node_6',['node',['../structremoteproc__mem.html#ac7785a8734ad1a571d1e9c1381586b52',1,'remoteproc_mem::node()'],['../structremoteproc__virtio.html#a0785231ae09a45a2e0ed8556759e61ca',1,'remoteproc_virtio::node()'],['../structrpmsg__endpoint.html#a8a522b5477c53ee46a7aae7536d4d7f2',1,'rpmsg_endpoint::node()']]],
  ['notify_7',['notify',['../structremoteproc__ops.html#a2fdca8af6a67da06e4e36a99eae86f05',1,'remoteproc_ops::notify()'],['../structremoteproc__virtio.html#a5853c3fa83520ecb010cb1dea00e376c',1,'remoteproc_virtio::notify()'],['../structvirtio__dispatch.html#ab0278191d6115fb90eca7e22dcaf523a',1,'virtio_dispatch::notify()'],['../structvirtqueue.html#a7ed3cb303d51f5c5898937098ff6aa2b',1,'virtqueue::notify()']]],
  ['notifyid_8',['notifyid',['../structfw__rsc__vdev__vring.html#a49a44e5f6032814541f09be5d5d8ede2',1,'fw_rsc_vdev_vring::notifyid()'],['../structfw__rsc__vdev.html#a6de2a78cef6cfcae51f0f4505847415a',1,'fw_rsc_vdev::notifyid()'],['../structvirtio__vring__info.html#a33c87c4d1f4b7926ed56f9d7ca88f920',1,'virtio_vring_info::notifyid()'],['../structvirtio__device.html#aa1bb85743a26751a0527489b9a97baa4',1,'virtio_device::notifyid()']]],
  ['ns_5fbind_5fcb_9',['ns_bind_cb',['../structrpmsg__device.html#a53c006f3ce03eaf017118e7fc03890b7',1,'rpmsg_device']]],
  ['ns_5fept_10',['ns_ept',['../structrpmsg__device.html#ae069dffc17794a512303daa18ddaa0f5',1,'rpmsg_device']]],
  ['ns_5funbind_5fcb_11',['ns_unbind_cb',['../structrpmsg__endpoint.html#a536a2e0f7ef7c0e3847a44ac04b2f23a',1,'rpmsg_endpoint::ns_unbind_cb()'],['../structrpmsg__device.html#ae0ef8db3f789b9fa68a6e17e99c2e1eb',1,'rpmsg_device::ns_unbind_cb()']]],
  ['num_12',['num',['../structresource__table.html#a43e189ad28a2e4a51043919cec17d55c',1,'resource_table::num()'],['../structfw__rsc__vdev__vring.html#a98e4d1aaf5f227b492addecb1bb25f65',1,'fw_rsc_vdev_vring::num()'],['../structvring.html#ac043819cbd514bb54a472b7b0c5c0255',1,'vring::num()']]],
  ['num_5fdescs_13',['num_descs',['../structvring__alloc__info.html#a60ca0f12eeea1842c3ae1c2d62d3b965',1,'vring_alloc_info']]],
  ['num_5fof_5fvrings_14',['num_of_vrings',['../structfw__rsc__vdev.html#a989c5b79b8c456612b7edd2b32d6b86f',1,'fw_rsc_vdev']]]
];
