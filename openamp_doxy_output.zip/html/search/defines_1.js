var searchData=
[
  ['close_5fsyscall_5fid_0',['CLOSE_SYSCALL_ID',['../rpmsg__retarget_8h.html#a6b8342f5d60475734cfdd8c2ed8023e8',1,'rpmsg_retarget.h']]]
];
