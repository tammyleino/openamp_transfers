var searchData=
[
  ['find_5frsc_0',['find_rsc',['../rsc__table__parser_8h.html#a7f8d965a0692da51850de2abee463407',1,'find_rsc(void *rsc_table, unsigned int rsc_type, unsigned int index):&#160;rsc_table_parser.c'],['../rsc__table__parser_8c.html#a7f8d965a0692da51850de2abee463407',1,'find_rsc(void *rsc_table, unsigned int rsc_type, unsigned int index):&#160;rsc_table_parser.c']]],
  ['find_5fservice_1',['find_service',['../rpmsg__rpc__client_8c.html#a3f6f289e2ac5a535310e6a8501f3e8a2',1,'find_service(struct rpmsg_rpc_clt *rpc, uint32_t id):&#160;rpmsg_rpc_client.c'],['../rpmsg__rpc__server_8c.html#a4b6cf9c5047006f8954cea9096afe235',1,'find_service(struct rpmsg_rpc_svr *rpcs, unsigned int id):&#160;rpmsg_rpc_server.c']]]
];
