var searchData=
[
  ['virtio_5fdevice_0',['virtio_device',['../structvirtio__device.html',1,'']]],
  ['virtio_5fdevice_5fid_1',['virtio_device_id',['../structvirtio__device__id.html',1,'']]],
  ['virtio_5fdispatch_2',['virtio_dispatch',['../structvirtio__dispatch.html',1,'']]],
  ['virtio_5ffeature_5fdesc_3',['virtio_feature_desc',['../structvirtio__feature__desc.html',1,'']]],
  ['virtio_5fvring_5finfo_4',['virtio_vring_info',['../structvirtio__vring__info.html',1,'']]],
  ['virtqueue_5',['virtqueue',['../structvirtqueue.html',1,'']]],
  ['virtqueue_5fbuf_6',['virtqueue_buf',['../structvirtqueue__buf.html',1,'']]],
  ['vq_5fdesc_5fextra_7',['vq_desc_extra',['../structvq__desc__extra.html',1,'']]],
  ['vring_8',['vring',['../structvring.html',1,'']]],
  ['vring_5falloc_5finfo_9',['vring_alloc_info',['../structvring__alloc__info.html',1,'']]],
  ['vring_5favail_10',['vring_avail',['../structvring__avail.html',1,'']]],
  ['vring_5fdesc_11',['vring_desc',['../structvring__desc.html',1,'']]],
  ['vring_5fused_12',['vring_used',['../structvring__used.html',1,'']]],
  ['vring_5fused_5felem_13',['vring_used_elem',['../structvring__used__elem.html',1,'']]]
];
