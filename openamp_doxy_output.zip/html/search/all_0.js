var searchData=
[
  ['_5fclose_0',['_close',['../rpmsg__retarget_8c.html#a58a559c63748012aab165d5f82af766d',1,'rpmsg_retarget.c']]],
  ['_5fopen_1',['_open',['../rpmsg__retarget_8c.html#abb62a535f19f82407dcd1d36c6b7770c',1,'rpmsg_retarget.c']]],
  ['_5fread_2',['_read',['../rpmsg__retarget_8c.html#acf9f6eb32431f15c8884c5ef94e664c3',1,'rpmsg_retarget.c']]],
  ['_5frpmsg_5fvirtio_5fget_5fbuffer_5fsize_3',['_rpmsg_virtio_get_buffer_size',['../rpmsg__virtio_8c.html#a1772b443b9f479c7eba545a490e780f5',1,'rpmsg_virtio.c']]],
  ['_5fwrite_4',['_write',['../rpmsg__retarget_8c.html#a73756a3a32b163ca5c38af57c1ed7ce5',1,'rpmsg_retarget.c']]]
];
