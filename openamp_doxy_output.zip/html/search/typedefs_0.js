var searchData=
[
  ['app_5fcb_0',['app_cb',['../rpmsg__rpc__client__server_8h.html#a66d6146908a6bbcbc9e61dfdf1922b32',1,'rpmsg_rpc_client_server.h']]]
];
