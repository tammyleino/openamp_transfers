var searchData=
[
  ['callback_0',['callback',['../structvirtqueue.html#a4a2f46e1e65d20c6f7a9a6a3d4637e94',1,'virtqueue']]],
  ['cb_1',['cb',['../structrpmsg__endpoint.html#a31fddff68db12a88c9e418cdd0a71d07',1,'rpmsg_endpoint::cb()'],['../structrpmsg__rpc__client__services.html#a1ed6ceba3ebccd146073e740eb1c061b',1,'rpmsg_rpc_client_services::cb()']]],
  ['cb_5ffunction_2',['cb_function',['../structrpmsg__rpc__services.html#a5ead68fc218a2b900bd37d138a37881e',1,'rpmsg_rpc_services']]],
  ['close_3',['close',['../structimage__store__ops.html#a39efaa6c4f74c99951f865efabfc21db',1,'image_store_ops']]],
  ['config_4',['config',['../structremoteproc__ops.html#a93e17ab08d6571322084e1933e460365',1,'remoteproc_ops::config()'],['../structrpmsg__virtio__device.html#aece781bf914def03cca2e3af8e21391f',1,'rpmsg_virtio_device::config()']]],
  ['config_5flen_5',['config_len',['../structfw__rsc__vdev.html#a648c89707ce8995950aa0c62bc4b3a47',1,'fw_rsc_vdev']]],
  ['cookie_6',['cookie',['../structvq__desc__extra.html#a173ba0bda32b3a2f1cce3af4084f474f',1,'vq_desc_extra']]]
];
