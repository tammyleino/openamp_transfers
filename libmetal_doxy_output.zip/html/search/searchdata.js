var indexSectionsWithContent =
{
  0: "_abcdefghilmnoprstuvw",
  1: "m",
  2: "acdeilmstuv",
  3: "_mst",
  4: "_abcdghilmnoprstvw",
  5: "am",
  6: "m",
  7: "m",
  8: "_aefghlmnr",
  9: "abcdilmst"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros",
  9: "Modules"
};

