var searchData=
[
  ['remoteproc_5fstate_0',['remoteproc_state',['../remoteproc_8h.html#ade9aec99672816c093b767bf6a8ae108',1,'remoteproc.h']]],
  ['rpmsg_5fns_5fflags_1',['rpmsg_ns_flags',['../rpmsg__internal_8h.html#aae8af25ce18492d5dfad107b5097c49c',1,'rpmsg_internal.h']]]
];
