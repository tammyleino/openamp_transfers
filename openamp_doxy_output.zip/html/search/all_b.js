var searchData=
[
  ['max_5fbuf_5flen_0',['MAX_BUF_LEN',['../rpmsg__rpc__client__server_8h.html#aaccf16bc2fc3e3fc0a1e4a0a55219295',1,'MAX_BUF_LEN():&#160;rpmsg_rpc_client_server.h'],['../rpmsg__retarget_8c.html#aaccf16bc2fc3e3fc0a1e4a0a55219295',1,'MAX_BUF_LEN():&#160;rpmsg_retarget.c']]],
  ['max_5ffunc_5fid_5flen_1',['MAX_FUNC_ID_LEN',['../rpmsg__rpc__client__server_8h.html#a8b3e82650ab4551cc099829f0d40cd96',1,'rpmsg_rpc_client_server.h']]],
  ['mems_2',['mems',['../structremoteproc.html#a2ce887e8ff18ebaae67ae4225cab4f67',1,'remoteproc']]],
  ['metal_5fpacked_5fend_3',['METAL_PACKED_END',['../remoteproc_8h.html#a9c3534a022afffeed1880924dce4d0d1',1,'METAL_PACKED_END():&#160;remoteproc.h'],['../rpmsg__rpc__client__server_8h.html#a48fd2f4732be4da1963c67e37a52649a',1,'METAL_PACKED_END():&#160;rpmsg_rpc_client_server.h'],['../virtio__ring_8h.html#a0a3a295176e983ddfc3d3fe669ec164e',1,'METAL_PACKED_END():&#160;virtio_ring.h'],['../rpmsg__internal_8h.html#a9c3534a022afffeed1880924dce4d0d1',1,'METAL_PACKED_END():&#160;rpmsg_internal.h']]],
  ['mmap_4',['mmap',['../structremoteproc__ops.html#afcf189833cd13a759b6092aaeede99ec',1,'remoteproc_ops']]]
];
