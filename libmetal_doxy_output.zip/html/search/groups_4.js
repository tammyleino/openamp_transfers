var searchData=
[
  ['interrupt_20handling_20interfaces_0',['Interrupt Handling Interfaces',['../group__irq.html',1,'']]],
  ['io_20interfaces_1',['IO Interfaces',['../group__io.html',1,'']]],
  ['irq_20interrupt_20handling_20interfaces_2',['irq Interrupt Handling Interfaces',['../group__soft.html',1,'']]]
];
