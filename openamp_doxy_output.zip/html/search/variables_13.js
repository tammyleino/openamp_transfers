var searchData=
[
  ['write_5fconfig_0',['write_config',['../structvirtio__dispatch.html#adcf2884b1e1dfaafd09629ccd54eb823',1,'virtio_dispatch']]]
];
