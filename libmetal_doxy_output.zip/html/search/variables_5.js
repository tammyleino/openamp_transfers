var searchData=
[
  ['generic_5fdevice_5flist_0',['generic_device_list',['../structmetal__common__state.html#a6fe99825ec2fb2d2388f598a1339a2c7',1,'metal_common_state']]],
  ['generic_5fshmem_5flist_1',['generic_shmem_list',['../structmetal__common__state.html#a4e6dbc8ec1a13f26a28c82b079f10395',1,'metal_common_state']]]
];
