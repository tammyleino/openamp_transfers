var searchData=
[
  ['addr_0',['addr',['../structrpmsg__endpoint.html#a3f14756de1dc50edbfa931cbf9609121',1,'rpmsg_endpoint::addr()'],['../structvring__desc.html#a24012b95247951b86e962f1acf538aa5',1,'vring_desc::addr()'],['../structrpmsg__ns__msg.html#a528c593df29289715a78147bbc2072be',1,'rpmsg_ns_msg::addr()']]],
  ['align_1',['align',['../structfw__rsc__vdev__vring.html#a3b4e46b5ce2fc8567b6913ef618a092f',1,'fw_rsc_vdev_vring::align()'],['../structvring__alloc__info.html#a781143b24c8e4ef9c2b2cf58c2ffd5f3',1,'vring_alloc_info::align()']]],
  ['args_2',['args',['../structrpmsg__rpc__syscall.html#a486f313f74f83499146ce145366d463b',1,'rpmsg_rpc_syscall']]],
  ['avail_3',['avail',['../structrpmsg__virtio__shm__pool.html#a3a4892788a011b4c72f5c2666afe9fcf',1,'rpmsg_virtio_shm_pool::avail()'],['../structvring.html#a66e01c52cba641a1df4fa8bb94f71ac8',1,'vring::avail()']]]
];
