var searchData=
[
  ['metal_5fcntr_5firq_5fregister_0',['metal_cntr_irq_register',['../group__irq.html#ga22c994407d005793e478ac8267744f88',1,'irq_controller.h']]],
  ['metal_5firq_5fhandler_1',['metal_irq_handler',['../group__irq.html#ga4fd6caa764267fc62373ae22e17aea2a',1,'irq.h']]],
  ['metal_5firq_5fset_5fenable_2',['metal_irq_set_enable',['../group__irq.html#ga125a768ecd5924b3da91b6ebb6820e9a',1,'irq_controller.h']]],
  ['metal_5firq_5ft_3',['metal_irq_t',['../group__system.html#ga5b3ecd7ba1914b26547392ceadec813c',1,'sys.h']]],
  ['metal_5flog_5fhandler_4',['metal_log_handler',['../group__logging.html#gaa79b2a8962227bb67c242b98afda292a',1,'log.h']]],
  ['metal_5fmutex_5ft_5',['metal_mutex_t',['../system_2nuttx_2mutex_8h.html#aad22123e8beb290ce87ded38c245166d',1,'metal_mutex_t():&#160;mutex.h'],['../system_2zephyr_2mutex_8h.html#a2cb46905b9132fc930921db5ed499252',1,'metal_mutex_t():&#160;mutex.h']]],
  ['metal_5fphys_5faddr_5ft_6',['metal_phys_addr_t',['../group__system.html#gae024fa10b72199a3e26c29b6eb97df5d',1,'sys.h']]]
];
