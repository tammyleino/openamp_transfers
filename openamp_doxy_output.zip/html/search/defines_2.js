var searchData=
[
  ['default_5fproxy_5fendpoint_0',['DEFAULT_PROXY_ENDPOINT',['../rpmsg__retarget_8h.html#ae3ad8c9a3ad4a1b43ec6c3815ffbbb90',1,'rpmsg_retarget.h']]]
];
