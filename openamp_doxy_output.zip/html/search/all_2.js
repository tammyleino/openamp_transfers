var searchData=
[
  ['base_0',['base',['../structrpmsg__virtio__shm__pool.html#ad099e53166964c1f8eac89d7cae64ef7',1,'rpmsg_virtio_shm_pool']]],
  ['bitmap_1',['bitmap',['../structremoteproc.html#ac2d3820c6b79fd570bc9465616ad2197',1,'remoteproc::bitmap()'],['../structrpmsg__device.html#a2bfe58aa854d3effc06f2a546dc946bb',1,'rpmsg_device::bitmap()']]],
  ['bootaddr_2',['bootaddr',['../structremoteproc.html#aee5c096afe2f4fbeac3d6422afab4319',1,'remoteproc']]],
  ['buf_3',['buf',['../structvirtqueue__buf.html#a313327b59499a8539f8c68193cdd002e',1,'virtqueue_buf']]],
  ['buflock_4',['buflock',['../structrpmsg__rpc__data.html#a127f4c08a6f247024c5ca959d6efc075',1,'rpmsg_rpc_data']]]
];
