var searchData=
[
  ['restrict_0',['restrict',['../compiler_2gcc_2compiler_8h.html#a080abdcb9c02438f1cd2bb707af25af8',1,'restrict():&#160;compiler.h'],['../compiler_2iar_2compiler_8h.html#a080abdcb9c02438f1cd2bb707af25af8',1,'restrict():&#160;compiler.h']]]
];
