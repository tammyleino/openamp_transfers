var searchData=
[
  ['allocation_20interfaces_0',['Allocation Interfaces',['../group__Memory.html',1,'']]]
];
