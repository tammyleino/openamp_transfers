var searchData=
[
  ['offset_0',['offset',['../structresource__table.html#a450ecd15b1e836a2ce52d45ddd476508',1,'resource_table']]],
  ['open_1',['open',['../structimage__store__ops.html#a97898ba90603f94071052a4707d9b16d',1,'image_store_ops']]],
  ['ops_2',['ops',['../structremoteproc.html#ae3386cebb7b3ca8144256f54b2345792',1,'remoteproc::ops()'],['../structrpmsg__device.html#a6d64414925149ade6b73e1352998fd30',1,'rpmsg_device::ops()']]]
];
