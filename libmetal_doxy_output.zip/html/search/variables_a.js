var searchData=
[
  ['name_0',['name',['../structmetal__bus.html#a38fdc374275d87bb04dab29f9ad53e0b',1,'metal_bus::name()'],['../structmetal__device.html#a25e7f2938bdfbb0f44ce11331b93950c',1,'metal_device::name()'],['../structmetal__generic__shmem.html#a304ef67e964e7ba1e9a8e3034272ce98',1,'metal_generic_shmem::name()']]],
  ['next_1',['next',['../structmetal__list.html#ac230ff75196e672a80c4a4520294a7fc',1,'metal_list']]],
  ['node_2',['node',['../structmetal__bus.html#a1af389eaabcb3daa33e7794acfbe446b',1,'metal_bus::node()'],['../structmetal__device.html#acafd9802f3390dfefbdb6040be7028db',1,'metal_device::node()'],['../structmetal__irq__controller.html#a26e87c0da6978319075db2289b901749',1,'metal_irq_controller::node()'],['../structmetal__generic__shmem.html#ad944a8261f79fa83d29c9d7cfd7b2103',1,'metal_generic_shmem::node()']]],
  ['num_5fpage_5fsizes_3',['num_page_sizes',['../structmetal__state.html#a08ea681743f49b2410a685518b033ce3',1,'metal_state']]],
  ['num_5fregions_4',['num_regions',['../structmetal__device.html#ab224bb579781a75e939373e23e1a7691',1,'metal_device']]]
];
