var searchData=
[
  ['term_5fsyscall_5fid_0',['TERM_SYSCALL_ID',['../rpmsg__retarget_8h.html#a638bd81bd75c20e7fe393a8de77adcb2',1,'rpmsg_retarget.h']]]
];
