var searchData=
[
  ['term_5fsyscall_5fid_0',['TERM_SYSCALL_ID',['../rpmsg__retarget_8h.html#a638bd81bd75c20e7fe393a8de77adcb2',1,'rpmsg_retarget.h']]],
  ['type_1',['type',['../structfw__rsc__hdr.html#a6997df7b8f7015dcc0beaf09756b6eae',1,'fw_rsc_hdr::type()'],['../structfw__rsc__carveout.html#a4ab738e31709c88b24053c734749a8ac',1,'fw_rsc_carveout::type()'],['../structfw__rsc__devmem.html#a8c1cc03313e4872f9e550d95c854b4f1',1,'fw_rsc_devmem::type()'],['../structfw__rsc__trace.html#adf2c4e4660e170a4cd8b7d64c5f4ae45',1,'fw_rsc_trace::type()'],['../structfw__rsc__vdev.html#a8f48ce72528850f35c700727bf6569f6',1,'fw_rsc_vdev::type()'],['../structfw__rsc__vendor.html#ad1ecc96decf335ca7c13a31819e88e90',1,'fw_rsc_vendor::type()']]]
];
