var searchData=
[
  ['v_0',['v',['../structmetal__spinlock.html#ae3695afc6004a2d35e2965fc634307a9',1,'metal_spinlock::v()'],['../structmetal__condition.html#a18f14ef5fa6b870c55112dc661f08887',1,'metal_condition::v()'],['../structmetal__mutex__t.html#a53c99e19c962dfd308d887e681dc8897',1,'metal_mutex_t::v()']]],
  ['virt_1',['virt',['../structmetal__sg.html#a9db82b2b09bffaa793c0293c9d02faed',1,'metal_sg::virt()'],['../structmetal__io__region.html#aaa1ddf24b37d257080e3db253f82d760',1,'metal_io_region::virt()']]]
];
