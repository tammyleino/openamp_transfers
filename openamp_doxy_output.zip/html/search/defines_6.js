var searchData=
[
  ['max_5fbuf_5flen_0',['MAX_BUF_LEN',['../rpmsg__rpc__client__server_8h.html#aaccf16bc2fc3e3fc0a1e4a0a55219295',1,'MAX_BUF_LEN():&#160;rpmsg_rpc_client_server.h'],['../rpmsg__retarget_8c.html#aaccf16bc2fc3e3fc0a1e4a0a55219295',1,'MAX_BUF_LEN():&#160;rpmsg_retarget.c']]],
  ['max_5ffunc_5fid_5flen_1',['MAX_FUNC_ID_LEN',['../rpmsg__rpc__client__server_8h.html#a8b3e82650ab4551cc099829f0d40cd96',1,'rpmsg_rpc_client_server.h']]]
];
