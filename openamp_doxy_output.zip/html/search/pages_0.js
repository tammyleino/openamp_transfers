var searchData=
[
  ['openamp_5fdocs_0',['openamp_docs',['../md__r_e_a_d_m_e.html',1,'']]]
];
