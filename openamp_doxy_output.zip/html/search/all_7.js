var searchData=
[
  ['get_5fentry_0',['get_entry',['../structloader__ops.html#a79bc15492c224c821d43796294eb5b0a',1,'loader_ops']]],
  ['get_5ffeatures_1',['get_features',['../structvirtio__dispatch.html#abe9edbec581401a3e0651a101fcce96f',1,'virtio_dispatch']]],
  ['get_5fload_5fstate_2',['get_load_state',['../structloader__ops.html#ae58c4eccc28f17e1f48b61191ebbeac1',1,'loader_ops']]],
  ['get_5fmem_3',['get_mem',['../structremoteproc__ops.html#a07b73d21691c764f400aad885cef7c82',1,'remoteproc_ops']]],
  ['get_5fstatus_4',['get_status',['../structvirtio__dispatch.html#ab08669d1a380c2a848101870960bc424',1,'virtio_dispatch']]],
  ['get_5ftx_5fpayload_5fbuffer_5',['get_tx_payload_buffer',['../structrpmsg__device__ops.html#a8dba83c70f683f309ce89ca849322f79',1,'rpmsg_device_ops']]],
  ['gfeatures_6',['gfeatures',['../structfw__rsc__vdev.html#aba8a74104a094e958041b69dac3501c1',1,'fw_rsc_vdev']]]
];
