var searchData=
[
  ['waiters_0',['waiters',['../structmetal__condition.html#a518ab57574502db086f2c5e344d20770',1,'metal_condition']]],
  ['wakeups_1',['wakeups',['../structmetal__condition.html#a0d86a2776c2ed87e610c15fe9395b0a9',1,'metal_condition']]],
  ['write_2',['write',['../structmetal__io__ops.html#a322ff06f9ee06132d4008d2578b2ef68',1,'metal_io_ops']]]
];
