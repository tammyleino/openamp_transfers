var searchData=
[
  ['openamp_5fversion_0',['openamp_version',['../group__versions.html#ga5fb1ba9eb8a7241a2cc07eef3904e534',1,'openamp_version(void):&#160;version.c'],['../group__versions.html#ga5fb1ba9eb8a7241a2cc07eef3904e534',1,'openamp_version(void):&#160;version.c']]],
  ['openamp_5fversion_5fmajor_1',['openamp_version_major',['../group__versions.html#gaf862d0a92f1649d5abbdfc843530676b',1,'openamp_version_major(void):&#160;version.c'],['../group__versions.html#gaf862d0a92f1649d5abbdfc843530676b',1,'openamp_version_major(void):&#160;version.c']]],
  ['openamp_5fversion_5fminor_2',['openamp_version_minor',['../group__versions.html#ga8cfa0c4e4af138c410cec550db9f206f',1,'openamp_version_minor(void):&#160;version.c'],['../group__versions.html#ga8cfa0c4e4af138c410cec550db9f206f',1,'openamp_version_minor(void):&#160;version.c']]],
  ['openamp_5fversion_5fpatch_3',['openamp_version_patch',['../group__versions.html#ga26cfd186be71c4b5805c93460915e059',1,'openamp_version_patch(void):&#160;version.c'],['../group__versions.html#ga26cfd186be71c4b5805c93460915e059',1,'openamp_version_patch(void):&#160;version.c']]]
];
