var searchData=
[
  ['ns_5fper_5fs_0',['NS_PER_S',['../linux_2time_8c.html#a8c0ffc2d7c29accf086889074d776ec0',1,'time.c']]]
];
