var searchData=
[
  ['da_0',['da',['../structfw__rsc__carveout.html#ad63e06080c5a7598adfaabb9407a3112',1,'fw_rsc_carveout::da()'],['../structfw__rsc__devmem.html#a2534c488d213b76d23887c622ef46025',1,'fw_rsc_devmem::da()'],['../structfw__rsc__trace.html#a01df2c0be72e987e03c99b692e989727',1,'fw_rsc_trace::da()'],['../structfw__rsc__vdev__vring.html#a315724ee3a0597a05b514fd3ff19a4ef',1,'fw_rsc_vdev_vring::da()'],['../structremoteproc__mem.html#a92a213c3d904be87e6a786c5a8948868',1,'remoteproc_mem::da()']]],
  ['data_1',['data',['../structfw__rsc__hdr.html#acaa796cefbb53d882f01537271a6b23c',1,'fw_rsc_hdr']]],
  ['data_5flen_2',['data_len',['../structrpmsg__rpc__syscall__header.html#aa8bfc0c990ab17b2ca56c3a51affd95f',1,'rpmsg_rpc_syscall_header']]],
  ['desc_3',['desc',['../structvring.html#a631a4d1e3208b63191f420929429c659',1,'vring']]],
  ['dest_5faddr_4',['dest_addr',['../structrpmsg__endpoint.html#a595766a3ed230683c2b7961e24cc39be',1,'rpmsg_endpoint']]],
  ['device_5',['device',['../structvirtio__device__id.html#a7f701324a9ab96a252e22d0a3cd7790c',1,'virtio_device_id']]],
  ['dfeatures_6',['dfeatures',['../structfw__rsc__vdev.html#ab464678383a5bd8adb2d6cff49edf118',1,'fw_rsc_vdev']]],
  ['dst_7',['dst',['../structrpmsg__hdr.html#a473d2427ef33238e92c48317493be589',1,'rpmsg_hdr']]]
];
