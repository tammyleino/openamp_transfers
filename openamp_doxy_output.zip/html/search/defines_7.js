var searchData=
[
  ['open_5fsyscall_5fid_0',['OPEN_SYSCALL_ID',['../rpmsg__retarget_8h.html#a2247aff4221f48c8d8261bcb9965c41f',1,'rpmsg_retarget.h']]]
];
