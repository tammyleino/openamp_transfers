var searchData=
[
  ['offset_0',['offset',['../structresource__table.html#a450ecd15b1e836a2ce52d45ddd476508',1,'resource_table']]],
  ['open_1',['open',['../structimage__store__ops.html#a97898ba90603f94071052a4707d9b16d',1,'image_store_ops']]],
  ['open_5famp_2eh_2',['open_amp.h',['../open__amp_8h.html',1,'']]],
  ['open_5fsyscall_5fid_3',['OPEN_SYSCALL_ID',['../rpmsg__retarget_8h.html#a2247aff4221f48c8d8261bcb9965c41f',1,'rpmsg_retarget.h']]],
  ['openamp_5fversion_4',['openamp_version',['../group__versions.html#ga5fb1ba9eb8a7241a2cc07eef3904e534',1,'openamp_version(void):&#160;version.c'],['../group__versions.html#ga5fb1ba9eb8a7241a2cc07eef3904e534',1,'openamp_version(void):&#160;version.c']]],
  ['openamp_5fversion_5fmajor_5',['openamp_version_major',['../group__versions.html#gaf862d0a92f1649d5abbdfc843530676b',1,'openamp_version_major(void):&#160;version.c'],['../group__versions.html#gaf862d0a92f1649d5abbdfc843530676b',1,'openamp_version_major(void):&#160;version.c']]],
  ['openamp_5fversion_5fminor_6',['openamp_version_minor',['../group__versions.html#ga8cfa0c4e4af138c410cec550db9f206f',1,'openamp_version_minor(void):&#160;version.c'],['../group__versions.html#ga8cfa0c4e4af138c410cec550db9f206f',1,'openamp_version_minor(void):&#160;version.c']]],
  ['openamp_5fversion_5fpatch_7',['openamp_version_patch',['../group__versions.html#ga26cfd186be71c4b5805c93460915e059',1,'openamp_version_patch(void):&#160;version.c'],['../group__versions.html#ga26cfd186be71c4b5805c93460915e059',1,'openamp_version_patch(void):&#160;version.c']]],
  ['ops_8',['ops',['../structremoteproc.html#ae3386cebb7b3ca8144256f54b2345792',1,'remoteproc::ops()'],['../structrpmsg__device.html#a6d64414925149ade6b73e1352998fd30',1,'rpmsg_device::ops()']]]
];
