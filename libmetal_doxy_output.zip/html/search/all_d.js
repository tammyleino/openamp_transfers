var searchData=
[
  ['offset_5fto_5fphys_0',['offset_to_phys',['../structmetal__io__ops.html#a609d8698238e0895b98fdc5c4fad67a3',1,'metal_io_ops']]],
  ['ops_1',['ops',['../structmetal__bus.html#ad42ebfcf7b0971f28fad6992a8e4c8fd',1,'metal_bus::ops()'],['../structmetal__io__region.html#a8d0a8ff10072b864af2ea913d135faf1',1,'metal_io_region::ops()']]]
];
