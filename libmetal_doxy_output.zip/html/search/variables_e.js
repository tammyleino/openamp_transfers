var searchData=
[
  ['size_0',['size',['../structmetal__io__region.html#a131ebc3df546c6e87b1f833882d9fc1e',1,'metal_io_region']]],
  ['sysfs_5fpath_1',['sysfs_path',['../structmetal__state.html#adb50fd0d288917778f721619dcaba32e',1,'metal_state']]]
];
