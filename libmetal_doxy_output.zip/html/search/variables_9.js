var searchData=
[
  ['m_0',['m',['../structmetal__condition.html#a424d948a9bebdc54fd34b3b89d667140',1,'metal_condition::m()'],['../structmetal__mutex__t.html#a42b9e13134d14c97d17000b7222fec9d',1,'metal_mutex_t::m()']]],
  ['mem_5fflags_1',['mem_flags',['../structmetal__io__region.html#a457b7d189af94966273824a9a95b1cc1',1,'metal_io_region']]],
  ['metal_5fgeneric_5fbus_2',['metal_generic_bus',['../group__device.html#gab25f549ea3a9151e82c033dd219bbfe5',1,'metal_generic_bus():&#160;device.c'],['../group__device.html#gab25f549ea3a9151e82c033dd219bbfe5',1,'metal_generic_bus():&#160;device.c'],['../group__device.html#gab25f549ea3a9151e82c033dd219bbfe5',1,'metal_generic_bus():&#160;device.c']]],
  ['metal_5fio_5fphys_5fstart_5f_3',['metal_io_phys_start_',['../system_2nuttx_2io_8c.html#a5ffdedfa11ebef9305f511b90ae5d9bb',1,'io.c']]],
  ['metal_5fio_5fregion_5f_4',['metal_io_region_',['../system_2nuttx_2io_8c.html#a7606f5b17ae71385edb0c0845a01f61c',1,'io.c']]],
  ['metal_5flinux_5fbus_5fops_5',['metal_linux_bus_ops',['../system_2linux_2device_8c.html#a8fa541afe7299c15be47e4959f36c782',1,'device.c']]],
  ['metal_5fshmem_5fio_5fops_6',['metal_shmem_io_ops',['../system_2linux_2shmem_8c.html#af2033f6ef4155d14288093aaac97f29d',1,'shmem.c']]],
  ['metal_5fsoftirq_5favail_7',['metal_softirq_avail',['../softirq_8c.html#a470e1baa97a9b3e6a31a112867694060',1,'softirq.c']]],
  ['mmap_5fflags_8',['mmap_flags',['../structmetal__page__size.html#ad397236c18313e189cb99b31bad74750',1,'metal_page_size']]],
  ['mptr_9',['mptr',['../structmetal__condition.html#af8373265030f4b57ea2670797ff0adad',1,'metal_condition']]]
];
